<div class="alert alert-danger" style="text-align: center;font-family: Verdana;font-weight: bold;border-radius: 0px;margin-bottom: 0px;">
  <span class="glyphicon glyphicon-warning-sign"></span> Le mode maintenance a été activé , seul les administrateurs on accès au site internet ! <span class="glyphicon glyphicon-warning-sign"></span>
</div>