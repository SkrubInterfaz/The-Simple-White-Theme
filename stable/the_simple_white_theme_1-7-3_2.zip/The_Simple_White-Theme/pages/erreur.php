<div class="heading">
		<h1 class="text-center wow fadeInDown"  data-wow-delay="2.1s" style="color:white;">Erreur</h1>
</div>
<section class="layout" id="page">
<div class="container">
	<div class="card" style="display: block; margin-left: 20%; text-align: center; margin-right: 20%; margin-top: 12%; padding-top: 2%; padding-bottom: 2%;">
		<div class="card-body">
		    <h4 class="card-title"><?=$titre;?></h4>
		    <h6 class="card-subtitle mb-2 text-muted"><?=$type;?></h6>
		    <p class="card-text"><?=$contenue;?></p>
		    <a href="index.php" class="card-link btn btn-primary btn-lg"><i class="fas fa-home"></i>Retourner sur l'accueil</a>
	  	</div>
	</div>
</div>
</section>
